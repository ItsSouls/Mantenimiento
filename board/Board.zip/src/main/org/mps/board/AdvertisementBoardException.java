package org.mps.board;

public class AdvertisementBoardException extends RuntimeException {
    public AdvertisementBoardException(String msg) {
        super(msg);
    }
}
